/*
 * FahrenheitTemperature.cpp
 *
 *  Date: [3/30/2023]
 *  Author: [Travis London]
 */

# include <iostream>
# include <fstream>
# include <string>
# include <vector>
# include <stdexcept>

using namespace std;

int FahrenheitToCelcius(int);
void InputData(vector<string>&, vector<int>&);
void OutputData(vector<string>&, vector<int>&);

int main() {
	vector<string> nameList;
	vector<int> tempList;
	try {
		InputData(nameList, tempList);
		OutputData(nameList, tempList);
	}
	catch (exception& runtime_error) {
		cout << runtime_error.what();
	}
	return 0;
}
int FahrenheitToCelcius(int temperatureF) {
	int temperatureC;
	temperatureC = static_cast<int>(temperatureF - 32) * (5.0 / 9);
	return temperatureC;
}
void InputData(vector<string>& nameList, vector<int>& tempList) {
	ifstream inFS;
	string cityName;
	int cityTemperatureF;
	int cityTemperatureC;

	inFS.open("FahrenheitTemperature.txt");
	if (!inFS.is_open()) {
		throw exception("Unable to open input file");
	}
	inFS >> cityName;
	while (!inFS.fail()) {
		nameList.push_back(cityName);
		inFS >> cityTemperatureF;
		if (inFS.fail()) {
			cout << "Line" << nameList.size() << ": No temperature found for" << cityName << endl;
			tempList.push_back(NULL);
		}
		else {
			cityTemperatureC = FahrenheitToCelcius(cityTemperatureF);
			tempList.push_back(cityTemperatureC);
		}
		inFS.ignore();
		inFS.clear();
		inFS >> cityName;
	}
	inFS.close();
}
void OutputData(vector<string>& nameList, vector<int>& tempList) {
	ofstream outFS;
	outFS.open("CelsiusTemperature.txt");

	if (!outFS.is_open()) {
		throw exception("Unable to open output file");
	}
	for (int i = 0; i < nameList.size(); i++) {
		outFS << nameList.at(i) << "" << tempList.at(i) << endl;
	}
		outFS.close();
}